### Istruzioni
1. Clonare il repository.
2. Creare le classi e i metodi mancanti affinché il codice compili correttamente
3. Eseguire i test e modificare le classi e i metodi appena creati affinché i test funzionino correttamente

### Chiarimenti
- **Se non si conosce junit:** esistono due rami, `main` e `test`.
Il codice va scritto nel ramo `main` mentre i test già presenti non vanno modificati.

- Si può utilizzare un IDE a scelta che sia in grado di eseguire gli unit test o in
alternativa tramite maven usando `mvn test`.